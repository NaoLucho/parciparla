
--
-- Vider la table avant d'insérer `g_listitem`
--

TRUNCATE TABLE `g_listitem`;
--
-- Contenu de la table `g_listitem`
--

INSERT INTO `g_listitem` (`id`, `list_id`, `name`) VALUES
(1, 1, 'Association'),
(2, 1, 'Entreprise'),
(3, 2, 'dzqzqd'),
(4, 2, 'qdqzdzqdzqdqzdqz'),
(5, 2, 'zadzada'),
(6, 3, 'zadazazd'),
(7, 3, 'aazezae'),
(8, 1, 'Organisme');
