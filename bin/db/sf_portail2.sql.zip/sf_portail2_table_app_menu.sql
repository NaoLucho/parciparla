
--
-- Vider la table avant d'insérer `app_menu`
--

TRUNCATE TABLE `app_menu`;
--
-- Contenu de la table `app_menu`
--

INSERT INTO `app_menu` (`id`, `name`) VALUES
(1, 'Principal'),
(2, 'Exemples'),
(3, 'Footer');
