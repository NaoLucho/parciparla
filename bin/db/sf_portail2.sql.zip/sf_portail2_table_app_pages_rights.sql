
--
-- Vider la table avant d'insérer `app_pages_rights`
--

TRUNCATE TABLE `app_pages_rights`;
--
-- Contenu de la table `app_pages_rights`
--

INSERT INTO `app_pages_rights` (`page_id`, `group_id`) VALUES
(1, 2),
(2, 1),
(3, 1),
(4, 1),
(4, 2),
(5, 2),
(6, 2),
(7, 2),
(8, 2),
(9, 2),
(10, 1),
(11, 2),
(12, 2),
(12, 5),
(13, 2),
(14, 2);
