
--
-- Vider la table avant d'insérer `fos_user_user_group`
--

TRUNCATE TABLE `fos_user_user_group`;
--
-- Contenu de la table `fos_user_user_group`
--

INSERT INTO `fos_user_user_group` (`user_id`, `group_id`) VALUES
(2, 1),
(4, 5),
(5, 6),
(6, 7);
