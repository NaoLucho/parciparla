
--
-- Vider la table avant d'insérer `g_list`
--

TRUNCATE TABLE `g_list`;
--
-- Contenu de la table `g_list`
--

INSERT INTO `g_list` (`id`, `name`) VALUES
(1, 'structureType'),
(2, 'Compétence'),
(3, 'skills');
