
--
-- Vider la table avant d'insérer `app_contents_rights`
--

TRUNCATE TABLE `app_contents_rights`;
--
-- Contenu de la table `app_contents_rights`
--

INSERT INTO `app_contents_rights` (`content_id`, `group_id`) VALUES
(2, 1),
(4, 1),
(4, 2),
(4, 6),
(8, 1),
(10, 2),
(11, 5),
(21, 1),
(21, 2),
(21, 7),
(25, 6);
